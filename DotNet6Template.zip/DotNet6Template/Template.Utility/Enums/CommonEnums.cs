﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template.Utility.Enums
{
    public class CommonEnums
    {
        public enum UserRole
        {
            SuperAdmin,
            Admin,
            Manager
        }
    }
    }
